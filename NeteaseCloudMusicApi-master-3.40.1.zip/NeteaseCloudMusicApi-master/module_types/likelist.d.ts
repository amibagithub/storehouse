import { RequestBaseConfig } from './base'

export interface LikelistRequestConfig extends RequestBaseConfig {
  uid: string | number
}
