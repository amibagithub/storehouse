import { RequestBaseConfig } from './base'

export interface RelatedAllvideoRequestConfig extends RequestBaseConfig {
  id: string | number
}
