import { RequestBaseConfig } from './base'

export interface DailySigninRequestConfig extends RequestBaseConfig {
  type?: 0 | 1
}
