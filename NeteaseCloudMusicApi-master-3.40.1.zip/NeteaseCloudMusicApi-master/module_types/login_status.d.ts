import { RequestBaseConfig } from './base'

export type LoginStatusRequestConfig = RequestBaseConfig
