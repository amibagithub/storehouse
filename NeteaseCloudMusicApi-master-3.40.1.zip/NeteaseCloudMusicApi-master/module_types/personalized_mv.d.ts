import { RequestBaseConfig } from './base'

export type PersonalizedMvRequestConfig = RequestBaseConfig
