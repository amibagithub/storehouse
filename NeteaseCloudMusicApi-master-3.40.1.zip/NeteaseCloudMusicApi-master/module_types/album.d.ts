import { RequestBaseConfig } from './base'

export interface AlbumRequestConfig extends RequestBaseConfig {
  id: string | number
}
