import { RequestBaseConfig } from './base'

export interface LyricRequestConfig extends RequestBaseConfig {
  id: string | number
}
