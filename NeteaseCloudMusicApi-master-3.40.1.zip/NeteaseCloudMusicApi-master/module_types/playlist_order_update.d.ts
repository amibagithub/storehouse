import { RequestBaseConfig } from './base'

export interface PlaylistOrderUpdateRequestConfig extends RequestBaseConfig {
  ids: string
}
