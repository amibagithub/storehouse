import { RequestBaseConfig } from './base'

export type DjCategoryRecommendRequestConfig = RequestBaseConfig
