import { RequestBaseConfig } from './base'

export type RecommendResourceRequestConfig = RequestBaseConfig
