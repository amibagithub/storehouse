import { RequestBaseConfig } from './base'

export type LogoutRequestConfig = RequestBaseConfig
