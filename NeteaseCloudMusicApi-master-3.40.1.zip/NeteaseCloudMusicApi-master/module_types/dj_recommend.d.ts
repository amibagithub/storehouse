import { RequestBaseConfig } from './base'

export type DjRecommendRequestConfig = RequestBaseConfig
