import { RequestBaseConfig } from './base'

export type AlbumNewestRequestConfig = RequestBaseConfig
