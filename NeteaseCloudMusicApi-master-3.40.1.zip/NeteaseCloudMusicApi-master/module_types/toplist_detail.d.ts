import { RequestBaseConfig } from './base'

export type ToplistDetailRequestConfig = RequestBaseConfig
