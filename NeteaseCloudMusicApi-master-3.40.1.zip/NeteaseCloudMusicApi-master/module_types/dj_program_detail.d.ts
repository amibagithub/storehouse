import { RequestBaseConfig } from './base'

export interface DjProgramDetailRequestConfig extends RequestBaseConfig {
  id: string | number
}
