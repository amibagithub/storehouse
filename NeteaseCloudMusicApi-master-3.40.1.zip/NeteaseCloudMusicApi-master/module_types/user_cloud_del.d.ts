import { RequestBaseConfig } from './base'

export interface UserCloudDelRequestConfig extends RequestBaseConfig {
  id: string | number
}
