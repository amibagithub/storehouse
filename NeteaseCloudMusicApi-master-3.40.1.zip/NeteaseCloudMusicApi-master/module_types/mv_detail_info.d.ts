import { RequestBaseConfig } from './base'

export interface MvDetailInfoRequestConfig extends RequestBaseConfig {
  mvid: string | number
}
