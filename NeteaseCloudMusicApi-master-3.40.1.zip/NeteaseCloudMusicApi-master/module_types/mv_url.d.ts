import { RequestBaseConfig } from './base'

export interface MvUrlRequestConfig extends RequestBaseConfig {
  id?: string | number
  r?: string | number
}
