import { RequestBaseConfig } from './base'

export type HistoryRecommendSongsRequestConfig = RequestBaseConfig
