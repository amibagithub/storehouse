import { RequestBaseConfig } from './base'

export interface DjDetailRequestConfig extends RequestBaseConfig {
  rid: string | number
}
