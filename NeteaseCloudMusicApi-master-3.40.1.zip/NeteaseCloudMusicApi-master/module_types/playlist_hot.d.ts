import { RequestBaseConfig } from './base'

export type PlaylistHotRequestConfig = RequestBaseConfig
