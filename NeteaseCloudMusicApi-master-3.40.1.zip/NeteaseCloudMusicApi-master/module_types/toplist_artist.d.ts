import { RequestBaseConfig } from './base'

export interface ToplistArtistRequestConfig extends RequestBaseConfig {
  type?: 1 | 2 | 3 | 4
}
