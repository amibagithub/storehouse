import { RequestBaseConfig } from './base'

export interface SimiMvRequestConfig extends RequestBaseConfig {
  mvid: string | number
}
