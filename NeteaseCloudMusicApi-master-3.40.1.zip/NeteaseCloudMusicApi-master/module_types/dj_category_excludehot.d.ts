import { RequestBaseConfig } from './base'

export type DjCategoryExcludehotRequestConfig = RequestBaseConfig
