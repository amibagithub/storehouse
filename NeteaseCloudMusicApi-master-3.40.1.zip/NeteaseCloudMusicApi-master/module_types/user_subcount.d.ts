import { RequestBaseConfig } from './base'

export type UserSubcountRequestConfig = RequestBaseConfig
