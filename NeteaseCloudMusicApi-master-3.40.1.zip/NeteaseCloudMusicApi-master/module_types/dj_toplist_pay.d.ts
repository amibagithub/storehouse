import { RequestBaseConfig } from './base'

export interface DjToplistPayRequestConfig extends RequestBaseConfig {
  limit?: string | number
}
