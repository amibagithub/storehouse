import { RequestBaseConfig } from './base'

export interface AlbumDetailRequestConfig extends RequestBaseConfig {
  id: string | number
}
