import { RequestBaseConfig } from './base'

export type HomepageDragonBallRequestConfig = RequestBaseConfig
