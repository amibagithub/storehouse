import { RequestBaseConfig } from './base'

export interface SimiArtistRequestConfig extends RequestBaseConfig {
  id: string | number
}
