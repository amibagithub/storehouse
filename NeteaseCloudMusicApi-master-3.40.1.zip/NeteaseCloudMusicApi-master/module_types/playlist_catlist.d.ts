import { RequestBaseConfig } from './base'

export type PlaylistCatlistRequestConfig = RequestBaseConfig
