import { RequestBaseConfig } from './base'

export interface DjToplistPopularRequestConfig extends RequestBaseConfig {
  limit?: string | number
}
