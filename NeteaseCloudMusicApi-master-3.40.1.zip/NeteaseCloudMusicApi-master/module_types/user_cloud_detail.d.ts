import { RequestBaseConfig } from './base'

export interface UserCloudDetailRequestConfig extends RequestBaseConfig {
  id: string | number
}
