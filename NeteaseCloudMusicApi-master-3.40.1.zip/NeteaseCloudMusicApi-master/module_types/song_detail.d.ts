import { RequestBaseConfig } from './base'

export interface SongDetailRequestConfig extends RequestBaseConfig {
  ids: string
}
