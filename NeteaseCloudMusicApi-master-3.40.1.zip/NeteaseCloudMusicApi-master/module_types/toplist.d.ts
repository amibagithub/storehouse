import { RequestBaseConfig } from './base'

export type ToplistRequestConfig = RequestBaseConfig
