import { RequestBaseConfig } from './base'

export type SearchDefaultRequestConfig = RequestBaseConfig
