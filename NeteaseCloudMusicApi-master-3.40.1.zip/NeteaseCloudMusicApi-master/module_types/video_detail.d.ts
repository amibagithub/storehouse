import { RequestBaseConfig } from './base'

export interface VideoDetailRequestConfig extends RequestBaseConfig {
  id: string
}
