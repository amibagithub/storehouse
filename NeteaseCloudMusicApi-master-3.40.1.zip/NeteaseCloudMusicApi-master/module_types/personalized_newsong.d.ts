import { RequestBaseConfig } from './base'

export type PersonalizedNewsongRequestConfig = RequestBaseConfig
