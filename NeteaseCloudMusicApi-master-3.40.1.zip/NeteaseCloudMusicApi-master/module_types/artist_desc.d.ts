import { RequestBaseConfig } from './base'

export interface ArtistDescRequestConfig extends RequestBaseConfig {
  id: string | number
}
