import { RequestBaseConfig } from './base'

export interface EventDelRequestConfig extends RequestBaseConfig {
  evId: string | number
}
