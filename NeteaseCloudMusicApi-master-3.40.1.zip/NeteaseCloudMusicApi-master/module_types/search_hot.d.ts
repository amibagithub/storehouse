import { RequestBaseConfig } from './base'

export type SearchHotRequestConfig = RequestBaseConfig
