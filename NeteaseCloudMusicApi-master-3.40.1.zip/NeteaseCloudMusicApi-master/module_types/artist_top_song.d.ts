import { RequestBaseConfig } from './base'

export interface ArtistTopSongRequestConfig extends RequestBaseConfig {
  id: string | number
}
