import { RequestBaseConfig } from './base'

export interface DjTodayPerferedRequestConfig extends RequestBaseConfig {
  page?: string | number
}
