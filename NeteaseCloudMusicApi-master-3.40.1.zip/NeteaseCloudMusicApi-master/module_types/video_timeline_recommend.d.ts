import { RequestBaseConfig } from './base'

export interface VideoTimelineRecommendRequestConfig extends RequestBaseConfig {
  offset?: string | number
}
