import { RequestBaseConfig } from './base'

export interface ArtistsRequestConfig extends RequestBaseConfig {
  id: string | number
}
