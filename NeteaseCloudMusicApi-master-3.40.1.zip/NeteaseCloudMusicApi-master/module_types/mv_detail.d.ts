import { RequestBaseConfig } from './base'

export interface MvDetailRequestConfig extends RequestBaseConfig {
  mvid?: string | number
}
