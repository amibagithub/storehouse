import { RequestBaseConfig } from './base'

export interface UserAudioRequestConfig extends RequestBaseConfig {
  uid: string | number
}
