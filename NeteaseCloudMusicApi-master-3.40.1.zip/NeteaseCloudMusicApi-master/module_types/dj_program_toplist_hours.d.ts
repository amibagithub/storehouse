import { RequestBaseConfig } from './base'

export interface DjProgramToplistHoursRequestConfig extends RequestBaseConfig {
  limit?: string | number
}
