import { RequestBaseConfig } from './base'

export type SettingRequestConfig = RequestBaseConfig
