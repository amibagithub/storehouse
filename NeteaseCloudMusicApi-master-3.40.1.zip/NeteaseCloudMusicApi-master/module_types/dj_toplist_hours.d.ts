import { RequestBaseConfig } from './base'

export interface DjToplistHoursRequestConfig extends RequestBaseConfig {
  limit?: string | number
}
