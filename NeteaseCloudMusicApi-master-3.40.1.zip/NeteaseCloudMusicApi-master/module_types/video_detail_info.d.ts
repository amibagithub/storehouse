import { RequestBaseConfig } from './base'

export interface VideoDetailInfoRequestConfig extends RequestBaseConfig {
  vid: string
}
