import { RequestBaseConfig } from './base'

export type PersonalizedDjprogramRequestConfig = RequestBaseConfig
