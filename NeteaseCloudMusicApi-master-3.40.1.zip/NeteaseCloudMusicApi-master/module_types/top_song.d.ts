import { RequestBaseConfig } from './base'

export interface TopSongRequestConfig extends RequestBaseConfig {
  type: 0 | 7 | 96 | 8 | 16
}
