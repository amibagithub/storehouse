import { RequestBaseConfig } from './base'

export interface BannerRequestConfig extends RequestBaseConfig {
  type?: 0 | 1 | 2 | 3
}
