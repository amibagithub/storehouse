import { RequestBaseConfig } from './base'

export type VideoGroupListRequestConfig = RequestBaseConfig
