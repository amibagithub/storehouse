import { RequestBaseConfig } from './base'

export interface ActivateInitProfileRequestConfig extends RequestBaseConfig {
  nickname: string
}
