import { RequestBaseConfig } from './base'

export type PersonalFmRequestConfig = RequestBaseConfig
