import { RequestBaseConfig } from './base'

export interface VideoTimelineAllRequestConfig extends RequestBaseConfig {
  offset?: string | number
}
