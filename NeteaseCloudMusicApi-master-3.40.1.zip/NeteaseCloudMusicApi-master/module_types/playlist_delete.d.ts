import { RequestBaseConfig } from './base'

export interface PlaylistDeleteRequestConfig extends RequestBaseConfig {
  id: string | number
}
