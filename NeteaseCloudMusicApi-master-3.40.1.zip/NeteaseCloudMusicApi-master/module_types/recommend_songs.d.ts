import { RequestBaseConfig } from './base'

export type RecommendSongsRequestConfig = RequestBaseConfig
