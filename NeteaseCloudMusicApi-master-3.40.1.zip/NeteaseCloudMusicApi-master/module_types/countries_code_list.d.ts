import { RequestBaseConfig } from './base'

export type CountriesCodeListRequestConfig = RequestBaseConfig
