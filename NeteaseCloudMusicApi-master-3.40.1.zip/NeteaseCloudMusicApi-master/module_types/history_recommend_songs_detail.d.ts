import { RequestBaseConfig } from './base'

export interface HistoryRecommendSongsDetailRequestConfig
  extends RequestBaseConfig {
  date?: string
}
