import { RequestBaseConfig } from './base'

export interface TopListRequestConfig extends RequestBaseConfig {
  id: string | number
}
