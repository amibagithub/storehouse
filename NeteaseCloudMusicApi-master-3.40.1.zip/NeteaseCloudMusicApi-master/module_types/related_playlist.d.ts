import { RequestBaseConfig } from './base'

export interface RelatedPlaylistRequestConfig extends RequestBaseConfig {
  id: string | number
}
