import { RequestBaseConfig } from './base'

export interface AlbumDetailDynamicRequestConfig extends RequestBaseConfig {
  id: string | number
}
