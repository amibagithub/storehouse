import { RequestBaseConfig } from './base'

export type DjBannerRequestConfig = RequestBaseConfig
