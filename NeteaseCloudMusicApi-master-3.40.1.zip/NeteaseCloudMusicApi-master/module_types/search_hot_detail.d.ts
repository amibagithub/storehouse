import { RequestBaseConfig } from './base'

export type SearchHotDetailRequestConfig = RequestBaseConfig
